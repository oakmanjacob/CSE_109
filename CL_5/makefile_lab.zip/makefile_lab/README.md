# Class Lab 8 - Makefile

## Contributers
* Jacob Oakman
* Brian Zhao

## Description
This is a multi-file shell program which returns hello world and gives the factorial of 5. Makefiles were created for this duing the in clas lab on 3/22/2019.a

## Build instructions
### Build

```
$> make -f Makefile
```

### Clean

```
$> make -f Makefile clean
```

